<?php
/**
 * Plugin Name: SEO House Core
 * Description: أنواع المحتوى والحقول وأداة تجهيز المحتوى وطلبات الاستشارة والسيو والبيانات المنظمة لموقع سيو هاوس. مستقلة عن الثيم حتى لا تضيع البيانات عند تغيير المظهر.
 * Version:           2.9.24
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Author: SEO House
 * Text Domain: seohouse-core
 * Domain Path: /languages
 *
 * @package SEOHouseCore
 */

defined( 'ABSPATH' ) || exit;

define( 'SH_CORE_VERSION', '2.9.24' );
define( 'SH_CORE_FILE', __FILE__ );
define( 'SH_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'SH_CORE_URL', plugin_dir_url( __FILE__ ) );
// the complete plugin (code + content pack): the verified file kept in the repository (release/)
define( 'SH_CORE_RELEASE_URL', 'https://raw.githubusercontent.com/YaserElshafey/seohouse/claude/design-v5-rollout/release/seohouse-core.zip' );

require SH_CORE_DIR . 'inc/helpers.php';
require SH_CORE_DIR . 'inc/i18n.php';
require SH_CORE_DIR . 'inc/post-types.php';
require SH_CORE_DIR . 'inc/acf.php';
require SH_CORE_DIR . 'inc/breadcrumbs.php';
require SH_CORE_DIR . 'inc/seo.php';
require SH_CORE_DIR . 'inc/authors.php';
require SH_CORE_DIR . 'inc/remote.php';
require SH_CORE_DIR . 'inc/content-transfer.php';
require SH_CORE_DIR . 'inc/case-studies.php';
require SH_CORE_DIR . 'inc/preview.php';
require SH_CORE_DIR . 'inc/protect.php';
require SH_CORE_DIR . 'inc/schema.php';
require SH_CORE_DIR . 'inc/rankmath.php';
require SH_CORE_DIR . 'inc/schema-check.php';
require SH_CORE_DIR . 'inc/platforms.php';
require SH_CORE_DIR . 'inc/reviews.php';
require SH_CORE_DIR . 'inc/migrate-posts.php';
require SH_CORE_DIR . 'inc/seo-transfer.php';
require SH_CORE_DIR . 'inc/hardening.php';
require SH_CORE_DIR . 'inc/leads.php';
require SH_CORE_DIR . 'inc/tracking.php';
require SH_CORE_DIR . 'inc/search.php';
require SH_CORE_DIR . 'inc/redirects.php';
require SH_CORE_DIR . 'inc/media.php';
require SH_CORE_DIR . 'inc/settings-tools.php';
require SH_CORE_DIR . 'inc/admin-cleanup.php';
require SH_CORE_DIR . 'inc/importer/class-importer.php';
require SH_CORE_DIR . 'inc/importer/admin.php';
require SH_CORE_DIR . 'inc/importer/legal.php';

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require SH_CORE_DIR . 'inc/importer/cli.php';
}

register_activation_hook(
	__FILE__,
	static function () {
		sh_core_register_post_types();
		flush_rewrite_rules( false );
		if ( ! get_option( 'sh_content_last_import' ) ) {
			update_option( 'sh_setup_redirect', 1, false );
		}
	}
);
register_deactivation_hook( __FILE__, static fn() => flush_rewrite_rules( false ) );

add_action( 'init', static fn() => load_plugin_textdomain( 'seohouse-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ) );

<?php
/**
 * Renders the sections of a design page template (ACF Group fields "s_<layout>", read through
 * sh_core_sections() in SEO House Core).
 * Each layout maps to sections/<page-key>/<layout>.php, or to sections/shared/<layout>.php
 * for shared components (FAQ, booking, related links).
 *
 * @package SEOHouse
 */

defined( 'ABSPATH' ) || exit;

/** Section rows of the current page (cached per request). */
function sh_sections_rows( ?int $post_id = null ): array {
	static $cache = array();
	$post_id = $post_id ? $post_id : (int) get_queried_object_id();
	if ( ! $post_id || ! sh_acf_ready() ) {
		return array();
	}
	if ( ! isset( $cache[ $post_id ] ) ) {
		$cache[ $post_id ] = sh_core_sections( $post_id );
	}
	return $cache[ $post_id ];
}

function sh_section_file( string $key, string $layout ): string {
	$own = "sections/{$key}/{$layout}";
	if ( locate_template( $own . '.php' ) ) {
		return $own;
	}
	$base = preg_replace( '/_\d+$/', '', $layout );
	if ( locate_template( "sections/shared/{$base}.php" ) ) {
		return "sections/shared/{$base}";
	}
	return '';
}

function sh_render_sections( string $key ): void {
	if ( ! sh_acf_ready() ) {
		if ( current_user_can( 'edit_pages' ) ) {
			echo '<div class="sh-admin-hint">' . esc_html__( 'حقول ACF غير متاحة؛ فعّل Advanced Custom Fields وإضافة SEO House Core.', 'seohouse' ) . '</div>';
		}
		return;
	}
	$rows = sh_sections_rows();
	if ( ! $rows ) {
		if ( current_user_can( 'edit_pages' ) ) {
			echo '<div class="sh-admin-hint">' . esc_html__( 'هذه الصفحة بلا أقسام بعد. أضف الأقسام من محرر الصفحة أو شغّل «تجهيز المحتوى» من إعدادات سيو هاوس.', 'seohouse' ) . '</div>';
		}
		return;
	}
	echo '<main id="main" class="sh-main">';
	$other_markets = in_array( $key, array( 'seo-ksa', 'seo-egypt', 'seo-uae' ), true ); // «خدماتنا في الأسواق العربية» before the FAQ
	// editors can look at hidden sections before showing them: ?sh_show_hidden=1 (marked, never for visitors)
	$show_hidden = ( isset( $_GET['sh_show_hidden'] ) && current_user_can( 'edit_pages' ) ) || ( function_exists( 'sh_cases_preview' ) && sh_cases_preview() ); // phpcs:ignore WordPress.Security.NonceVerification
	foreach ( $rows as $i => $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		if ( ! empty( $row['sh_hide'] ) ) {
			if ( ! $show_hidden ) {
				continue;
			}
			$row['sh_preview_hidden'] = true;
		}
		$layout = (string) ( $row['acf_fc_layout'] ?? '' );
		if ( $other_markets && ( str_starts_with( $layout, 'faq' ) || str_starts_with( $layout, 'booking' ) ) ) {
			get_template_part( 'parts/seo-other-markets', null, array( 'key' => $key ) );
			$other_markets = false;
		}
		if ( str_starts_with( $layout, 'reviews' ) && '' === sh_reviews_code() ) {
			continue; // no reviews source connected: no example testimonials
		}
		$file   = $layout ? sh_section_file( $key, $layout ) : '';
		if ( ! $file ) {
			continue;
		}
		get_template_part( $file, null, array( 'f' => $row, 'key' => $key, 'index' => $i ) );
	}
	echo '</main>';
}

/** Whether the current page renders a visible booking section (header CTA target). */
function sh_page_has_booking(): bool {
	if ( ! is_singular() ) {
		return false;
	}
	foreach ( sh_sections_rows() as $row ) {
		if ( is_array( $row ) && str_starts_with( (string) ( $row['acf_fc_layout'] ?? '' ), 'booking' ) && empty( $row['sh_hide'] ) ) {
			return true;
		}
	}
	return (bool) apply_filters( 'sh_page_has_booking', false );
}

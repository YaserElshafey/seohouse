<?php
/**
 * Visible breadcrumb. The trail itself comes from SEO House Core
 * (sh_breadcrumb_trail), which also feeds the BreadcrumbList schema, so both always match.
 *
 * @package SEOHouse
 */

defined( 'ABSPATH' ) || exit;

/** Breadcrumb trail; white on the blue heroes, page colours inside .sh-crumbs-light (theme.css). */
function sh_breadcrumbs(): void {
	$trail = function_exists( 'sh_breadcrumb_trail' ) ? sh_breadcrumb_trail() : array(
		array( 'label' => __( 'الرئيسية', 'seohouse' ), 'url' => home_url( '/' ) ),
		array( 'label' => wp_get_document_title(), 'url' => '' ),
	);
	if ( count( $trail ) < 2 ) {
		return;
	}
	$last = count( $trail ) - 1;
	echo '<nav aria-label="' . esc_attr__( 'مسار التنقل', 'seohouse' ) . '" style="display: flex; flex-wrap: wrap; align-items: center; gap: 8px; font-size: 13px; color: rgb(255, 255, 255);">';
	foreach ( $trail as $i => $c ) {
		if ( $i === $last ) {
			printf( '<span aria-current="page" style="color: rgb(255, 255, 255);">%s</span>', esc_html( $c['label'] ) );
		} else {
			printf( '<a href="%s" style="color: rgb(255, 255, 255);">%s</a><span aria-hidden="true">%s</span>', esc_url( $c['url'] ), esc_html( $c['label'] ), esc_html( sh_arrow() ) );
		}
	}
	echo '</nav>';
}
